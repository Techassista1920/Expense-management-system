<div class="col-sm-12">
				<p class="back-link">Contact us:XYZ@gmail.com</p>
			</div>