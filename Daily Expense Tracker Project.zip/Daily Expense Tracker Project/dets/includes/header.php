<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title style="color:white;">Daily Expense Tracker</title>
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/styles.css" rel="stylesheet">
  <style>
    body {
      padding-top: 50px; /* Adjust the padding for the fixed navbar */
    }

    .navbar {
      background-image: url('assets/images/background/blue.gif'); /* Replace with the path to your image */
      background-size: cover;
      background-repeat: no-repeat;
      background-position: center;
      border: none;
    }

    .navbar-brand {
      color: white; /* Change the color to your preferred color */
    }
    
    .navbar-brand span {
        color: white; /* Change the color to white */
    }
    
  </style>
</head>
<body>

<nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sidebar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="dashboard.php"><span>Daily Expense Tracker</span></a>
        </div>
    </div>
    <!-- /.container-fluid -->
</nav>

<!-- Rest of your HTML content -->

<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>
